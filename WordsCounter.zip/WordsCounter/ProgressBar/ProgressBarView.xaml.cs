﻿using System.Windows;

namespace WordsCounter.ProgressBar
{
    /// <summary>
    /// Interaction logic for PorgressBarView.xaml
    /// </summary>
    public partial class ProgressBarView : Window
    {
        public ProgressBarView()
        {
            InitializeComponent();
        }
    }
}
